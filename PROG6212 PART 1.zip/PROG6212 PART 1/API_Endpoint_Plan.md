# RaceDay – API Endpoint Plan

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| POST | /api/auth/register | Creates a new user account as either an Organiser or a Participant. | None (public) | `{ firstName, lastName, email, password, role }` | 201 Created – returns new user ID and role. 400 Bad Request – invalid/missing fields. 409 Conflict – email already registered. |
| POST | /api/auth/login | Authenticates a user and returns a JWT token used for all protected requests. | None (public) | `{ email, password }` | 200 OK – returns JWT token, userId, role. 401 Unauthorized – invalid credentials. |
| GET | /api/users/profile | Retrieves the profile of the currently logged-in user. | Any (logged in) | None | 200 OK – returns user details (excluding password). 401 Unauthorized – no/invalid token. |
| PUT | /api/users/profile | Updates the profile details of the currently logged-in user. | Any (logged in) | `{ firstName, lastName, contactNumber }` | 200 OK – returns updated profile. 400 Bad Request – invalid fields. 401 Unauthorized. |
| GET | /api/events | Lists all upcoming events. Used by Participants to browse events and by Organisers to see all events. | None (public) | None | 200 OK – returns array of events. |
| GET | /api/events/{id} | Retrieves full details of a single event, including its categories. | None (public) | None | 200 OK – returns event with nested categories. 404 Not Found – event does not exist. |
| POST | /api/events | Creates a new event. The logged-in Organiser becomes the event owner. | Organiser | `{ eventName, eventDate, location, description }` | 201 Created – returns new event ID. 400 Bad Request – invalid fields. 401 Unauthorized. 403 Forbidden – not an Organiser. |
| PUT | /api/events/{id} | Updates an existing event owned by the logged-in Organiser. | Organiser | `{ eventName, eventDate, location, description }` | 200 OK – returns updated event. 403 Forbidden – not the event owner. 404 Not Found. |
| DELETE | /api/events/{id} | Deletes an event owned by the logged-in Organiser. | Organiser | None | 200 OK – confirmation message. 403 Forbidden – not the event owner. 404 Not Found. |
| GET | /api/events/{id}/categories | Lists all categories for a specific event. | None (public) | None | 200 OK – returns array of categories. 404 Not Found – event does not exist. |
| POST | /api/events/{id}/categories | Adds a new category (e.g. 5km, 10km) to a specific event. | Organiser | `{ categoryName, distanceKm, entryFee }` | 201 Created – returns new category ID. 403 Forbidden – not the event owner. 404 Not Found – event does not exist. |
| PUT | /api/categories/{id} | Updates an existing category. | Organiser | `{ categoryName, distanceKm, entryFee }` | 200 OK – returns updated category. 403 Forbidden. 404 Not Found. |
| DELETE | /api/categories/{id} | Removes a category from an event. | Organiser | None | 200 OK – confirmation message. 403 Forbidden. 404 Not Found. |
| POST | /api/enrolments | Enrols the logged-in Participant into a chosen category for an event. | Participant | `{ categoryId }` | 201 Created – returns enrolment record with due status. 401 Unauthorized. 404 Not Found – category does not exist. 409 Conflict – already enrolled. |
| GET | /api/enrolments/my | Lists all enrolments (past and upcoming) belonging to the logged-in Participant. | Participant | None | 200 OK – returns array of the participant's enrolments. 401 Unauthorized. |
| GET | /api/events/{id}/enrolments | Lists all participants enrolled in a specific event, for the Organiser who owns it. | Organiser | None | 200 OK – returns array of enrolments with participant details. 403 Forbidden – not the event owner. 404 Not Found. |
| DELETE | /api/enrolments/{id} | Cancels a Participant's own enrolment before the event takes place. | Participant | None | 200 OK – confirmation message. 403 Forbidden – not the enrolment owner. 404 Not Found. |
| POST | /api/results | Captures the finishing result for a participant's enrolment. | Organiser | `{ enrolmentId, finishTime, position }` | 201 Created – returns new result record. 403 Forbidden – not the event owner. 404 Not Found – enrolment does not exist. 409 Conflict – result already captured. |
| PUT | /api/results/{id} | Updates a previously captured result (e.g. correcting a time). | Organiser | `{ finishTime, position }` | 200 OK – returns updated result. 403 Forbidden. 404 Not Found. |
| GET | /api/results/my | Retrieves all of the logged-in Participant's personal results across events. | Participant | None | 200 OK – returns array of results with event/category context. 401 Unauthorized. |
| GET | /api/events/{id}/results | Retrieves the full results list for a specific event (leaderboard). | None (public) | None | 200 OK – returns array of results ordered by position. 404 Not Found – event does not exist. |

**Notes:**
- All protected routes expect a `Bearer` JWT token in the `Authorization` header; if missing or invalid, the API returns `401 Unauthorized`.
- `Role Required = Organiser` or `Participant` means the token's role claim must match; otherwise the API returns `403 Forbidden`.
- Ownership checks (e.g. an Organiser can only edit their own events) are enforced in the service layer, not just the role claim.

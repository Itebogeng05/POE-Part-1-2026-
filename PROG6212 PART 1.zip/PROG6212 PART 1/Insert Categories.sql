INSERT INTO Categories (EventID, CategoryName, DistanceKM, EntryFee)
VALUES
(1, '5km Fun Run',     5.00,  80.00),
(1, '10km Run',        10.00, 120.00),
(2, '40km Road Race',  40.00, 250.00),
(2, '80km Road Race',  80.00, 400.00),
(3, 'Half Marathon',   21.10, 300.00),
(3, 'Full Marathon',   42.20, 450.00);
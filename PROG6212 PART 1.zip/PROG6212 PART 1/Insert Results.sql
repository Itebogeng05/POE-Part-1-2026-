INSERT INTO Results (EnrolmentID, FinishTime, Position, Status)
VALUES
(1, '00:28:45', 3, 'Final'),
(3, '00:52:10', 7, 'Final')
